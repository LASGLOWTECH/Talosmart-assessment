import React from 'react'

export default function Navbar() {
  return (
    <div className='text-white bg-darkBlue '>
        
        <p className='text-white py-6 text-center'>
All rights reserved@ lasglowtech

        </p>
      </div>
  )
}
